# nextjs-mui-tailwind-template
NextJS 13.1 - MUI version 5.11 and TailwindCSS
